<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Beranda - Motifnesia</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"/>

  <style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap");

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    body {
      background-color: #f8f8f8;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    main {
      flex: 1;
      padding: 40px 5%;
      display: flex;
      justify-content: center;
      align-items: flex-start;
    }

    /* Container produk */
    .produk-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 25px;
      width: 50%;
      max-width: 1200px;
    }

    /* Kartu produk */
    .card-produk {
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: all 0.3s ease;
      text-decoration: none;
      color: black;
      display: flex;
      flex-direction: column;
    }

    .card-produk:hover {
      transform: scale(1.02);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .card-produk img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      background-color: #eee;
    }

    .info-produk {
      padding: 15px;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .nama-produk {
      font-size: 15px;
      font-weight: 600;
      margin-bottom: 8px;
      color: #222;
      height: 38px;
      overflow: hidden;
    }

    .harga-diskon {
      font-size: 16px;
      font-weight: 700;
      color: #000;
      margin-bottom: 4px;
    }

    .harga-normal {
      font-size: 13px;
      text-decoration: line-through;
      color: #d9534f;
      margin-right: 8px;
    }

    .diskon-label {
      font-size: 13px;
      color: green;
      font-weight: 500;
    }

    .rating {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 14px;
      color: #444;
      margin-top: 10px;
    }

    .rating i {
      color: #f4c430;
    }

    footer {
      background-color: burlywood;
      text-align: center;
      padding: 15px 0;
      font-size: 14px;
      color: #222;
    }

    /* Responsive kecil */
    @media (max-width: 600px) {
      main {
        padding: 20px;
      }

      .card-produk img {
        height: 160px;
      }

      .nama-produk {
        font-size: 14px;
      }
    }
  </style>
</head>

<body>

  <main>
    <div class="produk-container">
      <?php $__currentLoopData = $baju; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#" class="card-produk">
          <img src="<?php echo e(asset('asstes/img/' . $row['gambar'])); ?>" alt="<?php echo e($row['nama_produk']); ?>" />
          <div class="info-produk">
            <p class="nama-produk"><?php echo e($row['nama_produk']); ?></p>

            <?php if($row['diskon_persen'] > 0): ?>
              <p>
                <span class="harga-diskon">Rp<?php echo e(number_format($row['harga_diskon'], 0, ',', '.')); ?></span><br>
                <span class="harga-normal">Rp<?php echo e(number_format($row['harga'], 0, ',', '.')); ?></span>
                <span class="diskon-label">-<?php echo e($row['diskon_persen']); ?>%</span>
              </p>
            <?php else: ?>
              <p class="harga-diskon">Rp<?php echo e(number_format($row['harga'], 0, ',', '.')); ?></p>
            <?php endif; ?>

            <div class="rating">
              <i class="fa-solid fa-star"></i>
              <span><?php echo e($row['avg_rating']); ?></span>
            </div>
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </main>

  <footer>
    © 2025 Motifnesia
  </footer>

</body>
</html>
<?php /**PATH C:\Users\ASUS\motifnesia\resources\views/content/home.blade.php ENDPATH**/ ?>