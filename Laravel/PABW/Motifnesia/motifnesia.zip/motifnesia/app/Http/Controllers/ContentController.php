<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContentController extends Controller
{
    public function home()
    {
        // Data dummy untuk tampilan
        $baju = [
            [
                'id' => 1,
                'nama_produk' => 'Kemeja Batik Pria',
                'gambar' => 'baju1.jpg',
                'harga' => 250000,
                'diskon_persen' => 10,
                'harga_diskon' => 225000,
                'avg_rating' => 4.5
            ],
            [
                'id' => 2,
                'nama_produk' => 'Batik Wanita Modern',
                'gambar' => 'baju2.jpg',
                'harga' => 300000,
                'diskon_persen' => 0,
                'harga_diskon' => 300000,
                'avg_rating' => 4.8
            ],
        ];

        return view('content.home', compact('baju'));
    }
}
