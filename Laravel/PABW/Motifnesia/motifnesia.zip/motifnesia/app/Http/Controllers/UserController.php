<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    // Halaman login
    public function login()
    {
        return view('user.login');
    }

    // Proses login tanpa database
    public function doLogin(Request $request)
    {
        $username = $request->input('username');
        $password = $request->input('password');

        // Akun dummy
        $akun = [
            'username' => 'admin',
            'password' => '123456',
            'nama' => 'Admin Motifnesia'
        ];

        if ($username === $akun['username'] && $password === $akun['password']) {
            session(['user' => $akun]);
            return redirect()->route('home')->with('success', 'Berhasil login!');
        } else {
            return back()->with('error', 'Username atau password salah!');
        }
    }

    // Halaman register
    public function register()
    {
        return view('user.register');
    }

    // Halaman forgot password
    public function forgot()
    {
        return view('user.forgot');
    }

    // Logout
    public function logout()
    {
        session()->forget('user');
        return redirect()->route('login')->with('success', 'Berhasil logout.');
    }
}
