<h2>Tentang Motifnesia</h2>
<p>Motifnesia adalah platform untuk menampilkan berbagai motif kain khas Indonesia.</p>

<div>
  <h3>Slideshow Gambar</h3>
  <img src="{{ asset('img/motif1.jpg') }}" width="200">
  <img src="{{ asset('img/motif2.jpg') }}" width="200">
</div>
