<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

Route::get('/', [UserController::class, 'login'])->name('login');
Route::post('/login', [UserController::class, 'doLogin'])->name('doLogin');
Route::get('/register', [App\Http\Controllers\UserController::class, 'register'])->name('register');
Route::get('/forgot', [App\Http\Controllers\UserController::class, 'forgot'])->name('forgot');
Route::get('/logout', [UserController::class, 'logout'])->name('logout');
Route::get('/home', [App\Http\Controllers\ContentController::class, 'home'])->name('home');
