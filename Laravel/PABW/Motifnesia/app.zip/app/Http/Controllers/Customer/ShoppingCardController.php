<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produk;

class ShoppingCardController extends Controller
{
    public function index(Request $request)
    {
        $products = Produk::all();

        // cart disimpan di session
        $cart = session()->get('cart', []);

        return view('shoppingCard.index', compact('products', 'cart'));
    }

    public function add(Request $request)
    {
        $ids = $request->input('products', []); // array checkbox

        $cart = session()->get('cart', []);

        foreach ($ids as $id) {
            if (!isset($cart[$id])) {
                $cart[$id] = 1; // qty = 1 default
            }
        }

        session()->put('cart', $cart);

        return redirect()->route('shoppingCard.index')
                        ->with('success', 'Produk masuk cart.');
    }

    public function remove(Request $request)
    {
        $id = $request->input('id');

        $cart = session()->get('cart', []);

        unset($cart[$id]);

        session()->put('cart', $cart);

        return redirect()->route('shoppingCard.index')
                        ->with('success', 'Produk dihapus dari cart.');
    }
}
