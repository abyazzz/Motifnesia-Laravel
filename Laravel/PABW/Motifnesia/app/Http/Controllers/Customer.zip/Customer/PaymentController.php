<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductOrder;
use App\Models\ProductOrderItem;
use App\Models\MetodePengiriman;
use App\Models\MetodePembayaran;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    public function index()
    {
        $session = session('session_checkout_final');
        if (!$session) {
            return redirect()->route('customer.checkout.index');
        }
        return view('customer.pages.payment', [
            'checkout' => $session
        ]);
    }

    public function storeFinalOrder(Request $request)
    {
        $session = session('session_checkout_final');
        $user = session('user');
        $userId = $user['id'] ?? null;
        if (!$userId || !$session) {
            return redirect()->route('customer.checkout.index');
        }
        $paymentNumber = $request->input('payment_number_input');
        DB::beginTransaction();
        try {
            $order = ProductOrder::create([
                'user_id' => $userId,
                'alamat' => $session['alamat'],
                'metode_pengiriman_id' => $session['metode_pengiriman']['id'],
                'metode_pembayaran_id' => $session['metode_pembayaran']['id'],
                'subtotal_produk' => $session['subtotal_produk'],
                'total_ongkir' => $session['total_ongkir'],
                'total_bayar' => $session['total_bayar'],
                'payment_number' => $paymentNumber,
                'status' => 'pending',
                'created_at' => $session['created_at'] ?? now(),
            ]);
            foreach ($session['products'] as $item) {
                ProductOrderItem::create([
                    'product_order_id' => $order->id,
                    'produk_id' => $item['produk_id'],
                    'nama' => $item['nama'],
                    'harga' => $item['harga'],
                    'qty' => $item['qty'],
                    'subtotal' => $item['subtotal'],
                    'ukuran' => $item['ukuran'] ?? null,
                ]);
            }
            session()->forget(['session_checkout', 'session_checkout_final']);
            DB::commit();
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Gagal memproses pembayaran.']);
        }
    }
}
